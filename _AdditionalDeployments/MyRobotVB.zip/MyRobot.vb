﻿Imports MarvinsArena.Robot

''' <summary>
''' My robot
''' </summary>
''' <remarks></remarks>
Public Class MyRobot
    Inherits BaseRobot
    Implements IRobot

    ' This is the place to define class variables

    ''' <summary>
    ''' Initialize local variables
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Initialize() Implements IRobot.Initialize
        ' TODO: Assign values to variables and event handler
    End Sub

    ''' <summary>
    ''' Run the robot
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Run() Implements IRobot.Run
        ' TODO: Place your logic here
    End Sub
End Class
