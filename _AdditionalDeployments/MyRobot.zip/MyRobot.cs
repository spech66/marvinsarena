﻿using System;
using MarvinsArena.Robot;

namespace $safeprojectname$
{
	/// <summary>
	/// My robot
	/// </summary>
	public class $safeprojectname$ : BaseRobot, IRobot
	{
		// This is the place to define class variables

		/// <summary>
		/// Initialize local variables
		/// </summary>
		public void Initialize()
		{
			// TODO: Assign values to variables and event handler
		}

		/// <summary>
		/// Run the robot
		/// </summary>
		public void Run()
		{
			// TODO: Place your logic here
		}
	}
}
